const { default: ComingSoon } = require("../coming-soon")

const Testimonials = () => {
    return (
        <ComingSoon />
    )
}

export default Testimonials