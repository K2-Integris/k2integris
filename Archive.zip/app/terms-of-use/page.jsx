const { default: ComingSoon } = require("../coming-soon")

const TermsOfUse = () => {
    return (
        <ComingSoon />
    )
}

export default TermsOfUse