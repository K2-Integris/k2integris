const { default: ComingSoon } = require("../coming-soon")

const Work = () => {
    return (
        <ComingSoon />
    )
}

export default Work