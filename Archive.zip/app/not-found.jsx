const NotFound = () => {
  return (
    <section className="default">
      <div className="wrapper">
        <h1>
          <span>404</span>
          <br />
          This page was not found
        </h1>
      </div>
    </section>
  );
};

export default NotFound;
