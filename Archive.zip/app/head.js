export default function Head() {
  return (
    <>
      <link rel="preload" href="/css/home.css" as="style" />
      <link rel="stylesheet" href="/css/home.css" />
    </>
  );
}
