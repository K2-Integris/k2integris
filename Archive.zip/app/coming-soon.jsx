const ComingSoon = () => {
  return (
    <section className="default">
      <div className="wrapper">
        <h1>
            We're working on <br />something <span>amazing.</span><br />
            This page is <span>coming soon!</span>
        </h1>
      </div>
    </section>
  );
};

export default ComingSoon;

